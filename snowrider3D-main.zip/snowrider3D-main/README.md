# snowrider3d
Use the arrow keys or `A` and `D` to move. Use `W` or the up arrow to jump. Avoid obstacles by dodging them or going over them.
